package ua.nure.baranov.wumpus

case class WumpusPercept(glitter: Boolean,
                         stench: Boolean,
                         breeze: Boolean,
                         bump: Boolean,
                         scream: Boolean)
